/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import misclases.ConnMysql;
import misclases.Usuario;

/**
 *
 * @author xubuntu
 */
public class s1 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            HttpSession miSession;
            miSession = request.getSession();
            String usuario = request.getParameter("usuario");
            String pass = (String) request.getParameter("pass");
            Connection conn = new ConnMysql().getConnection();
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);

            if (request.getParameter("login") != null) {
                ResultSet rs = stmt.executeQuery("select * from usuario where usuario='" + usuario + "' and pass='" + pass + "';");
                Usuario user = new Usuario();
                if (rs.next()) {
                    user.setId(rs.getInt(1));
                    user.setUsuario(rs.getString(2));
                    user.setPass(rs.getString(3));
                    user.setRol(rs.getString(4));

                    miSession.setAttribute("usuario", user);

                    if (rs.getString(4).equals("u")) {
                        rs.close();
                        stmt.close();
                        conn.close();
                        request.getRequestDispatcher("/user.jsp").forward(request, response);
                    } else {
                        rs.close();
                        stmt.close();
                        conn.close();
                        request.getRequestDispatcher("/admin.jsp").forward(request, response);

                    }
                } else {
                    rs.close();
                    stmt.close();
                    conn.close();
                    out.println("Usuario no encontrado");
                    out.println("<br><a href=index.jsp>Volver a inicio</a>");
                }
            }

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(s1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(s1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
