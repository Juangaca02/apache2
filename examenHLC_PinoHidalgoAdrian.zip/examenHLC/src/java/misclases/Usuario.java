/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package misclases;

import java.sql.Date;

/**
 *
 * @author alejandro
 */
public class Usuario {
    int id;
    String usuario;
    String pass;
    String rol;
    
    public Usuario() {
        
    }

    public Usuario(int id, String usuario, String pass, String rol) {
        this.id = id;
        this.usuario = usuario;
        this.pass = pass;
        this.rol = rol;
    }
    
    public int getId() {
        return id;
    }

    public String getUsu() {
        return usuario;
    }

    public String getPass() {
        return pass;
    }
    
    public String getRol() {
        return rol;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
    
    public void setPass(String pass) {
        this.pass = pass;
    }
    
    public void setRol(String rol) {
        this.rol = rol;
    }

}
