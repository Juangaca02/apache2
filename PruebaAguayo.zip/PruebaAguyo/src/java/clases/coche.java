/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author xubuntu
 */
public class coche {
    
    int id;
    String matricula;
    String modelo;
    String color;

    public coche() {
    }

    public coche(int id, String matricula, String modelo, String color) {
        this.id = id;
        this.matricula = matricula;
        this.modelo = modelo;
        this.color = color;
    }

    @Override
    public String toString() {
        return "coche{" + "id=" + id + ", matricula=" + matricula + ", modelo=" + modelo + ", color=" + color + '}';
    }
    

    public int getId() {
        return id;
    }

    public String getMatricula() {
        return matricula;
    }

    public String getModelo() {
        return modelo;
    }

    public String getColor() {
        return color;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setColor(String color) {
        this.color = color;
    }

    
    
    
}
